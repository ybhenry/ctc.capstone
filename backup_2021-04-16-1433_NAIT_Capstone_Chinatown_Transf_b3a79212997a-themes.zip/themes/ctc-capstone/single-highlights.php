<?php
/***
*	The template for displaying individual blog posts (full article/blog post).
*
*   @package CTC Capstone Theme
*   @since 1.0.0
*/

//display header
get_header();
?>
<h1 class="contentHeading">SLICE OF LIFE</h1>
    <div class="pagination cptReturn">
		<div class="cptBack">
			<a href="https://ctc.web.dmitcapstone.ca/ctcCapstone/sliceoflife/">← Back</a>
		</div>
    </div>

<div class="flex-container">
    <?php if(have_posts()) : ?>
        <!-- start the loop -->
        <?php  while(have_posts()) : the_post(); ?>
            <div class="content-area">
                <!-- Title -->
				<div class="cptSingleHeader">
				    <?php the_title('<h2 class="singleHeading">', '</h2>'); ?> 
					<div class="cptSocials">
						<p>
							Share this content
						</p>
						 <?php echo do_shortcode('[DISPLAY_ULTIMATE_SOCIAL_ICONS]'); ?>
					</div>
				</div>

				<div class="cptSingleContent">
					<!-- Feat Image -->
					<?php echo get_the_post_thumbnail( $post->ID, 'large' ); ?>
					<?php the_content(); ?>				
				</div>
            </div>
        <?php  endwhile; ?>
	
        <!-- //end while loop -->
            <?php else : ?>
                <!-- send to search page / some other general page with search function, tags, categories, archives,etc.. --> 
                <?php get_template_part('template-parts/content', 'none'); ?>
        <?php endif; ?> 
	
		<div class="cptSocials">
			<p>
				Share this content
			</p>
				<?php echo do_shortcode('[DISPLAY_ULTIMATE_SOCIAL_ICONS]'); ?>
		</div>
        <!-- //out of the loop: this would be a good place to add sidebar to the right of the article/blog. --> 
    <!--//display footer -->
    <?php get_footer(); ?>

</div>
