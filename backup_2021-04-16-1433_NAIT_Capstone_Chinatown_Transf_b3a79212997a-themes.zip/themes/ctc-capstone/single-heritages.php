<?php
/***
*	The template for displaying individual blog posts (full article/blog post).
*
*   @package CTC Capstone Theme
*   @since 1.0.0
*/

//display header
get_header();
?>
<h1 class="contentHeading">Heritage</h1>
<div class="flex-container">
    <?php if(have_posts()) : ?>
        <!-- start the loop -->
        <?php  while(have_posts()) : the_post(); ?>
            <div class="content-area">
                <!-- Title -->
                <?php the_title('<h2 class="singleHeading">', '</h2>'); ?> 

                <!-- Feat Image -->
                <?php echo get_the_post_thumbnail( $post->ID, 'large' ); ?>
                
                <!-- Name/Date/Cate -->
                <ul>
                    <?php $card_footer = get_field('card_footer'); ?>
                    <li>
                        <?php 
                            $term = get_the_category();
                                if( $term ) {
                                    foreach($term as $t) {
                                        $t = get_term($t);
                                        print_r('<a href="' . get_term_link( $t ) . '"> ' .$t->name .'</a>');
                                    }
                                }
                            ?>
                    </li>
                </ul>

                <?php the_content(); ?>
            </div>
        <?php  endwhile; ?>
	
        <!-- //end while loop -->
            <?php else : ?>
                <!-- send to search page / some other general page with search function, tags, categories, archives,etc.. --> 
                <?php get_template_part('template-parts/content', 'none'); ?>
        <?php endif; ?> 
        <!-- //out of the loop: this would be a good place to add sidebar to the right of the article/blog. --> 
    <!--//display footer -->
    <?php get_footer(); ?>

</div>
