<?php
 /***
 * The template for displaying search results pages
 *
 * @package CTC Capstone Theme
 * @since 1.0
 */
 get_header();
 ?>

 <div class="wrapper" id="search-wrapper">
	 <?php if ( have_posts() ) : ?>
	<h1 class="entry-title">
		<?php
		printf(
			/* translators: %s: query term */
			esc_html__( 'YOU SEARCHED FOR:
                    %s', 'theme name here' ),
			'<span>' . get_search_query() .
			'</span>' . '<div class="header-underline-blog"></div>'
		);
		?>
	 </h1>
	 <div class="searchResults">
		 
		 <?php /* Start the Loop */ ?>

		 <?php while ( have_posts() ) : the_post(); ?>
		 <?php
		 get_template_part( 'template-parts/content', 'search' );
		 ?>
		 <?php endwhile; ?>
		 <?php else : ?>
		 <?php get_template_part( 'template-parts/content',
								 'none' ); ?>
		 <?php endif; ?>

	 </div><!-- .row -->
</div><!-- #search-wrapper -->
<?php get_footer();