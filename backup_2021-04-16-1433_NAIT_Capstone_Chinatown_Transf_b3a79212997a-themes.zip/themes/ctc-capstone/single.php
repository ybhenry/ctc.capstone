<?php
/***
*	The template for displaying individual blog posts (full article/blog post).
*
*   @package CTC Capstone Theme
*   @since 1.0.0
*/

//display header
get_header();
?>

    <?php if(have_posts()) : ?>
        <!-- start the loop -->
        <?php  while(have_posts()) : the_post(); ?>
            <?php
                //do things -- display content : the function below will pull the content from the template partial.
                get_template_part( 'template-parts/content', 'single' );
            ?>
        <?php  endwhile; ?>
        <!-- //end while loop -->
        <!-- add pagination -->
        <div class="pagination">
            <?php post_pagination(); ?>
        </div>
        
    <?php endif; ?> 
  
 <!--//display footer -->
<?php get_footer(); ?>

