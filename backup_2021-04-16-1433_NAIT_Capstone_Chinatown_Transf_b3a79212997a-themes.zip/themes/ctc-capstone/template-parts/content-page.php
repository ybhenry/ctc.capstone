<?php
/***
* Template part for displaying content in the single.php template (individual/article blog page)
* @link https://developer.wordpress.org/theme/basics/template-hierarchy/
*
*   @package CTC Capstone theme
* @since 1.0.0
*/
?>
<article <?php post_class();?> id="post-<?php the_ID();?>" >
    <!-- entry header -->
        <header>
        <!-- get the page title -->
            <?php the_title('<h1 class="entry-title">', '</h1>'); ?>
        </header>
        <div class="entry-content">
        <?php echo get_the_post_thumbnail( $post->ID, 'large' ); ?>
        <?php the_content(); ?>
    </div>
</article>
