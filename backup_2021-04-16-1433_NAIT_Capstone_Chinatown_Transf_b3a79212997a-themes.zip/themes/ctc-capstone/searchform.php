<?php
/**
 * The template for displaying search forms -> borrowed from understrap
 *
 * @package CTC Capstone Theme
 * @since 1.0
 */
?>
 <form method="get" id="searchform" action="<?php echo esc_url(
        home_url( '/' ) ); ?>" role="search">
        <label class="sr-only" for="s"><?php esc_html_e( '', 'theme
        name' ); ?></label>
    <div class="search-form">
		<button class="search-button" type="button">
			<img src="/miWP/wp-content/uploads/2021/03/search.svg" alt="Search">
		</button>
        <input id="s" name="s" type="text" placeholder="<?php
        esc_attr_e( 'SEARCH', 'demotheme' ); ?>" value="<?php
        the_search_query(); ?>">
        <input id="searchsubmit" class="visuallyHidden" name="submit" type="submit" value="<?php esc_attr_e( 'Search >', 'demotheme' ); ?>">
    </div>
 </form>
